-- Задание 2. Функция delete_car: удаление автомобиля при отсутствии внешних ссылок

CREATE OR REPLACE FUNCTION delete_car(
    _id BIGINT
)
RETURNS VOID
AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM trainer WHERE favorite_car_id = _id)
       OR EXISTS (SELECT 1 FROM trainer_car WHERE car_id = _id) THEN
        RAISE EXCEPTION 'Невозможно выполнить удаление, так как есть внешние ссылки'
            USING ERRCODE = 'foreign_key_violation',
                  DETAIL = format('На автомобиль с id = %s ссылаются таблицы trainer или trainer_car', _id);
    END IF;

    DELETE FROM car WHERE id = _id;
END;
$$ LANGUAGE plpgsql;

-- Автомобиль 12 (Volkswagen Beetle) не закреплён ни за одним тренером
SELECT delete_car(12);

-- На автомобиль 4 (Toyota Supra) ссылаются trainer и trainer_car
SELECT delete_car(4);

SELECT id, title FROM car WHERE id IN (4, 12);
