-- Задание 3. Функция фильтрации автомобилей по мощности

CREATE OR REPLACE FUNCTION filter_car_by_horsepower(
    _min_horsepower INT
)
RETURNS SETOF car
AS $$
BEGIN
    RETURN QUERY
        SELECT *
        FROM car
        WHERE horsepower >= _min_horsepower
        ORDER BY horsepower DESC;
END;
$$ LANGUAGE plpgsql;

SELECT id, title, horsepower, production_year, color
FROM filter_car_by_horsepower(300);
