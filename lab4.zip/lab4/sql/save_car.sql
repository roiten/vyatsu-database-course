-- Задание 1. Функция save_car: вставка или обновление строки таблицы car

CREATE OR REPLACE FUNCTION save_car(
    _id BIGINT,
    _title VARCHAR(100),
    _photo_url VARCHAR(255),
    _description TEXT,
    _horsepower INT,
    _production_year INT,
    _color VARCHAR(20),
    _suspension_name VARCHAR(100),
    _is_utilized BOOLEAN DEFAULT FALSE
)
RETURNS BIGINT
AS $$
DECLARE
    used_id BIGINT;
BEGIN
    IF _id IS NULL THEN
        INSERT INTO car (title, photo_url, description, horsepower,
                         production_year, color, suspension_name, is_utilized)
        VALUES (_title, _photo_url, _description, _horsepower,
                _production_year, _color, _suspension_name, _is_utilized)
        RETURNING id INTO used_id;
    ELSE
        UPDATE car SET
            title = _title,
            photo_url = _photo_url,
            description = _description,
            horsepower = _horsepower,
            production_year = _production_year,
            color = _color,
            suspension_name = _suspension_name,
            is_utilized = _is_utilized
        WHERE id = _id
        RETURNING id INTO used_id; -- останется NULL, если строки с таким id нет
    END IF;

    RETURN used_id;
END;
$$ LANGUAGE plpgsql;

-- Проверка: вставка новой строки
SELECT save_car(NULL, 'Subaru Impreza WRX STI', NULL,
                'Оппозитный турбомотор и симметричный полный привод.',
                300, 2006, 'Синий', 'MacPherson');

-- Проверка: изменение существующей строки
SELECT save_car(6, 'Peugeot 406', 'https://cars.pics/peugeot_406.jpg',
                'То самое такси из Марселя, после доработки мотора.',
                220, 1998, 'Белый', 'MacPherson');

-- Проверка: изменение несуществующей строки
SELECT save_car(999, 'Lada Granta', NULL, NULL, 98, 2015, 'Серый', 'MacPherson');

SELECT id, title, description, horsepower, production_year, color
FROM car
WHERE id IN (6, 13);
