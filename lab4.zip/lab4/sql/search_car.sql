-- Задание 6. Поиск автомобилей по необязательным критериям (динамический запрос)

CREATE OR REPLACE FUNCTION search_car(
    _title VARCHAR DEFAULT NULL,
    _color VARCHAR DEFAULT NULL,
    _min_horsepower INT DEFAULT NULL,
    _only_active BOOLEAN DEFAULT TRUE,
    _order_by TEXT DEFAULT 'id'
)
RETURNS SETOF car
AS $$
DECLARE
    query TEXT := 'SELECT * FROM car WHERE TRUE';
BEGIN
    IF _title IS NOT NULL THEN
        query := query || ' AND title ILIKE ''%'' || $1 || ''%''';
    END IF;
    IF _color IS NOT NULL THEN
        query := query || ' AND color = $2';
    END IF;
    IF _min_horsepower IS NOT NULL THEN
        query := query || ' AND horsepower >= $3';
    END IF;
    IF _only_active THEN
        query := query || ' AND NOT is_utilized';
    END IF;

    IF _order_by NOT IN ('id', 'title', 'horsepower', 'production_year') THEN
        RAISE EXCEPTION 'Недопустимый столбец для сортировки: %', _order_by;
    END IF;
    query := query || format(' ORDER BY %I', _order_by);

    RAISE NOTICE '%', query;

    RETURN QUERY EXECUTE query USING _title, _color, _min_horsepower;
END;
$$ LANGUAGE plpgsql;

-- Синие автомобили, отсортированные по мощности
SELECT id, title, color, horsepower
FROM search_car(_color => 'Синий', _order_by => 'horsepower');

-- Автомобили Audi мощностью от 250 л.с.
SELECT id, title, color, horsepower
FROM search_car(_title => 'audi', _min_horsepower => 250);

-- Все автомобили, включая утилизированные, по году выпуска
SELECT id, title, production_year, is_utilized
FROM search_car(_only_active => FALSE, _order_by => 'production_year');
